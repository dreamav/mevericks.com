/**
 * Created by VlooMan on 10.1.2014.
 */

function Vloo(){
    alert('ish_icon');
}